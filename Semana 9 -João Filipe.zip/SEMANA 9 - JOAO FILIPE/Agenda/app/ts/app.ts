import { Pessoa } from './pessoa';
import { Agenda } from './agenda';

let p1 = new Pessoa ();
p1.setNome('Joao');
p1.setanoDeNascimento(1992);
p1.setaltura(172);

let p2 = new Pessoa ();
p2.setNome('Carla');
p2.setanoDeNascimento(1991);
p2.setaltura(150);

let p3 = new Pessoa ();
p3.setNome('Gilberto');
p3.setanoDeNascimento(1990);
p3.setaltura(181);

let p4 = new Pessoa ();
p4.setNome('Kerline');
p4.setanoDeNascimento(1989);
p4.setaltura(167);

let p5 = new Pessoa ();
p5.setNome('Thais');
p5.setanoDeNascimento(1987);
p5.setaltura(177);

//Criacao de uma instancia da classe agenda 
let agenda = new Agenda ();

//Adicao das pessoas na instancia acima
agenda.armazenaPessoa(p1);
agenda.armazenaPessoa(p2);
agenda.armazenaPessoa(p3);
agenda.armazenaPessoa(p4);
agenda.armazenaPessoa(p5);

//Imprimir a agenda completa
agenda.imprimirAgenda();

//Imprimir a informacao de apenas um contato
let contatoEncontrado = agenda.buscaPessoa('Carla');
if (contatoEncontrado != null) {
  console.log('Contato Encontrado');
  console.log('Nome: ' + contatoEncontrado.getNome());
} else {
  console.log('Contato inexistente');
}