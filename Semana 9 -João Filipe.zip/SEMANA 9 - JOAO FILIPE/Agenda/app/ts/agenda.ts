import { Pessoa } from './pessoa';

export class Agenda {
    private _pessoas: Pessoa[] = [];
    
    public getContato(): Pessoa[] {
        return this._pessoas;
    }
    public setContato(contatos: Pessoa[]): void {
        this._pessoas = contatos;
    }
    public armazenaPessoa (pessoa: Pessoa) {
        this._pessoas.push(pessoa);
    }
    public buscaPessoa(nomeContato: string): Pessoa {
        let pessoa = null;
        for (let indice = 0; indice < this._pessoas.length; indice++) {
            if (this._pessoas[indice].getNome() === nomeContato) {
                pessoa = this._pessoas[indice];
            }
        }   
        return pessoa;
    }
    public imprimirAgenda() {
        for (let indice = 0; indice < this._pessoas.length; indice++) { 
            console.log(this._pessoas[indice].getNome());
        }  
    }
}