export class Pessoa {
    private _nome: string;
    private _anoDeNascimento: number;
    private _altura: number;

    public getNome(): string {
        return this._nome;
    }

    public setNome(nome: string): void {
        this._nome = nome;
    }

    public getanoDeNascimento(): number {
        return this._anoDeNascimento;
    }

    public setanoDeNascimento(anoDeNascimento: number): void {
        this._anoDeNascimento = anoDeNascimento;
    }

    public getaltura(): number {
        return this._altura;
    }

    public setaltura(altura: number): void {
        this._altura = altura;
    }
}