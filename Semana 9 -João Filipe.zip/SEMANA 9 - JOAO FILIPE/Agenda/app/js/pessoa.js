"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Pessoa = void 0;
var Pessoa = /** @class */ (function () {
    function Pessoa() {
    }
    Pessoa.prototype.getNome = function () {
        return this._nome;
    };
    Pessoa.prototype.setNome = function (nome) {
        this._nome = nome;
    };
    Pessoa.prototype.getanoDeNascimento = function () {
        return this._anoDeNascimento;
    };
    Pessoa.prototype.setanoDeNascimento = function (anoDeNascimento) {
        this._anoDeNascimento = anoDeNascimento;
    };
    Pessoa.prototype.getaltura = function () {
        return this._altura;
    };
    Pessoa.prototype.setaltura = function (altura) {
        this._altura = altura;
    };
    return Pessoa;
}());
exports.Pessoa = Pessoa;
