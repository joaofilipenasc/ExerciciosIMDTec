"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var pessoa_1 = require("./pessoa");
var agenda_1 = require("./agenda");
var p1 = new pessoa_1.Pessoa();
p1.setNome('Joao');
p1.setanoDeNascimento(1992);
p1.setaltura(172);
var p2 = new pessoa_1.Pessoa();
p2.setNome('Carla');
p2.setanoDeNascimento(1991);
p2.setaltura(150);
var p3 = new pessoa_1.Pessoa();
p3.setNome('Gilberto');
p3.setanoDeNascimento(1990);
p3.setaltura(181);
var p4 = new pessoa_1.Pessoa();
p4.setNome('Kerline');
p4.setanoDeNascimento(1989);
p4.setaltura(167);
var p5 = new pessoa_1.Pessoa();
p5.setNome('Thais');
p5.setanoDeNascimento(1987);
p5.setaltura(177);
//Criacao de uma instancia da classe agenda 
var agenda = new agenda_1.Agenda();
//Adicao das pessoas na instancia acima
agenda.armazenaPessoa(p1);
agenda.armazenaPessoa(p2);
agenda.armazenaPessoa(p3);
agenda.armazenaPessoa(p4);
agenda.armazenaPessoa(p5);
//Imprimir a agenda completa
agenda.imprimirAgenda();
//Imprimir a informacao de apenas um contato
var contatoEncontrado = agenda.buscaPessoa('Carla');
if (contatoEncontrado != null) {
    console.log('Contato Encontrado');
    console.log('Nome: ' + contatoEncontrado.getNome());
}
else {
    console.log('Contato inexistente');
}
