"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Agenda = void 0;
var Agenda = /** @class */ (function () {
    function Agenda() {
        this._pessoas = [];
    }
    Agenda.prototype.getContato = function () {
        return this._pessoas;
    };
    Agenda.prototype.setContato = function (contatos) {
        this._pessoas = contatos;
    };
    Agenda.prototype.armazenaPessoa = function (pessoa) {
        this._pessoas.push(pessoa);
    };
    Agenda.prototype.buscaPessoa = function (nomeContato) {
        var pessoa = null;
        for (var indice = 0; indice < this._pessoas.length; indice++) {
            if (this._pessoas[indice].getNome() === nomeContato) {
                pessoa = this._pessoas[indice];
            }
        }
        return pessoa;
    };
    Agenda.prototype.imprimirAgenda = function () {
        for (var indice = 0; indice < this._pessoas.length; indice++) {
            console.log(this._pessoas[indice].getNome());
        }
    };
    return Agenda;
}());
exports.Agenda = Agenda;
