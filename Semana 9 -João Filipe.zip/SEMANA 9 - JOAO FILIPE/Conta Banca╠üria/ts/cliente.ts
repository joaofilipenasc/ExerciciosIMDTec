export class Cliente {
    private _nome:string;
    
    public constructor(nome: string){
        this._nome = nome;
    }

    public get nome(): string {
        return this._nome;
    }

    public set nome(nome: string) {
        this._nome = nome;
    }
}