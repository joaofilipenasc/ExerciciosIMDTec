import { Endereco } from "./endereco";

export class Agencia {
    private _nome:string;
    private _endereco:Endereco;

    public constructor(nome: string, endereco: Endereco){
        this._nome = nome;
        this._endereco = endereco;
    }

    public get nome(): string {
        return this._nome;
    }

    public set nome(nome: string) {
        this._nome = nome;
    }

    public get endereco(): Endereco {
        return this._endereco;
    }

    public set endereco(endereco: Endereco) {
        this._endereco = endereco;
    }
}