import { Cliente } from "./cliente";
import { Agencia } from "./agencia";

export class Conta {
    private _cliente: Cliente;
    private _agencia: Agencia;
    private _numero: string;
    readonly _saldo: number;

    public constructor(cliente: Cliente, agencia: Agencia, numero: string, saldo: number){
        this._cliente = cliente;
        this._agencia = agencia;
        this._numero = numero;
        this._saldo = saldo;
    }

    public get cliente() : Cliente {
        return this._cliente;
    }

   public set cliente(cliente : Cliente) {
       this._cliente = cliente;
   }

   public get agencia() : Agencia {
        return this._agencia;
    }

    public set agencia(agencia : Agencia) {
        this._agencia = agencia;
    }
    
    public get numero(): string {
        return this._numero;
    }

    public set numero(numero: string) {
        this._numero = numero;
    }

    public get saldo(): number {
        return this._saldo;
    }

    public informacoesConta () {
        console.log("Numero da conta:"+this.numero +" Nome do cliene: "+this.cliente+" Saldo: "+this.saldo+" Nome da agencia: "+this.agencia+" Cidade: "+this.agencia+" Bairro: "+this.agencia);
    }
}