import { Conta } from './conta';

let conta = new Conta("Joao","Village","0905",1699);
conta.informacoesConta();
