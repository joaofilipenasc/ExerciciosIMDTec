export class Endereco {
    private _cidade:string;
    private _bairro:string;

    public constructor(cidade: string, bairro: string){
        this._cidade = cidade;
        this._bairro = bairro;
    }

    public get cidade(): string {
        return this._cidade;
    }

    public set cidade(cidade: string) {
        this._cidade = cidade;
    }

    public get bairro(): string {
        return this._bairro
    }

    public set bairro(bairro: string) {
        this._bairro = bairro;
    }
}