export class Pessoa{
    
    _nome: string;
    _sobrenome: string;
    _idade: number;

    constructor(nome:string, sobrenome: string, idade?: number) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.idade = idade; 
        
        if(idade != undefined){
            this.idade = idade;
        }else{
            this.idade = -1;
        } 

    }

    public get nome() : string {
        return this._nome;
    }

    public set nome(nome : string) {
        this._nome = nome;
    }
    
    public get sobrenome() : string {
        return this._sobrenome;
    }
    
    public set sobrenome(sobrenome : string) {
        this._sobrenome = sobrenome;
    }

    public get idade() : number {
        return this._idade;
    }
    
    public set idade(idade : number) {
        this._idade = idade;
    }

    public imprimirInformacoes() {
        console.log("Nome:"+this.nome +" Sobrenome: "+this.sobrenome+" Idade: "+this.idade);
    }

}

