import { Pessoa } from './pessoa';

let p1 = new Pessoa("Bolinha","Silva",20);

let p2 = new Pessoa("Fulaninha","Silvinha",21); 

let p3 = new Pessoa("Cicrana","Silvana",19);

let p4 = new Pessoa("Sirina","Sonserina");

p1.imprimirInformacoes();
p2.imprimirInformacoes();
p3.imprimirInformacoes();
p4.imprimirInformacoes();