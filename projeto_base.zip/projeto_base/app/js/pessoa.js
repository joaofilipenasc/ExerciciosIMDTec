"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Pessoa = void 0;
var Pessoa = /** @class */ (function () {
    function Pessoa(nome, sobrenome, idade) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.idade = idade;
        if (idade != undefined) {
            this.idade = idade;
        }
        else {
            this.idade = -1;
        }
    }
    Object.defineProperty(Pessoa.prototype, "nome", {
        get: function () {
            return this._nome;
        },
        set: function (nome) {
            this._nome = nome;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Pessoa.prototype, "sobrenome", {
        get: function () {
            return this._sobrenome;
        },
        set: function (sobrenome) {
            this._sobrenome = sobrenome;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Pessoa.prototype, "idade", {
        get: function () {
            return this._idade;
        },
        set: function (idade) {
            this._idade = idade;
        },
        enumerable: false,
        configurable: true
    });
    Pessoa.prototype.imprimirInformacoes = function () {
        console.log("Nome:" + this.nome + " Sobrenome: " + this.sobrenome + " Idade: " + this.idade);
    };
    return Pessoa;
}());
exports.Pessoa = Pessoa;
