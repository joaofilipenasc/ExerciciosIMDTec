var Pessoa = /** @class */ (function () {
    function Pessoa() {
    }
    Pessoa.prototype.getNome = function () {
        return this.nome;
    };
    Pessoa.prototype.setNome = function (nome) {
        this.nome = nome;
    };
    Pessoa.prototype.getSobrenome = function () {
        return this.sobrenome;
    };
    Pessoa.prototype.setSobrenome = function (sobrenome) {
        this.sobrenome = sobrenome;
    };
    Pessoa.prototype.getIdade = function () {
        return this.idade;
    };
    Pessoa.prototype.setIdade = function (idade) {
        this.idade = idade;
    };
    Pessoa.prototype.imprimirInformacoes = function () {
        console.log("Nome: " + this.nome + " Sobrenome: " + this.sobrenome + " Idade: " + this.idade);
    };
    return Pessoa;
}());
var pessoa = new Pessoa();
pessoa.setNome("Joao Filipe");
pessoa.setSobrenome("Nascimento");
pessoa.setIdade(28);
pessoa.imprimirInformacoes();
